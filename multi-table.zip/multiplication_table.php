<!DOCTYPE html>
<head>
	<meta charset="utf-8"/>
	<title>Multiplication Table</title>
	<meta name="Design a multiplication table using PHP">
	<link rel="stylesheet" href="multiply_style.css">
</head>
<body>
	<!-- <table>
	  <tr>
	     <td>1x1</td>
	     <td>1x2</td>
	     <td>1x3</td>
	  </tr>
	  <tr>
	     <td>2x1</td>
	     <td>2x2</td>
	     <td>2x3</td>
	  </tr>
	  <tr>
	     <td>3x1</td>
	     <td>3x2</td>
	     <td>3x3</td>
	  </tr>
	</table> -->
	<table>
		<?php echo 'YOU GOT THIS, ERIN!' ?>



		<?php 
			for($i=1; $i<=10; $i++){ 
		?>

		        <tr>

		<?php   
				for($j=1; $j<=10; $j++){ 
		?>
		        	<td><?php echo $i * $j; ?></td>
		<?php   } 
		?>
		      	</tr>
		<?php } 
		?>

		<?php


		?>
	</table>
</body>
</html>